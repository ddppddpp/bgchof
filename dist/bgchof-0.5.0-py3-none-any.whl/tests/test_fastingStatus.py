#check page 511, 512 in the Tipikon
#The rules there are concise enough and can be applied as a series of tests