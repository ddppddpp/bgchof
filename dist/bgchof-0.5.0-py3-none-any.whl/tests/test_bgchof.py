"""
simple tests

- calculate Easter Sunday for 2021 (should return May 2nd, 2021)
- get the fasting status for a known Good Friday date (i.e. Apr 30 2021)


more complex tests




"""