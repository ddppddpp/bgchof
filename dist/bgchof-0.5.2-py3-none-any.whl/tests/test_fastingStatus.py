# check page 511, 512 in the Tipikon
# The rules there are concise enough and can be applied as a series of tests
# probably test for a random series of dates
# should be something like self.arretIn(getStatusForDate, range(0,6))
